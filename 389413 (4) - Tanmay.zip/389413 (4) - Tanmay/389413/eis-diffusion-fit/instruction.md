Electrochemical impedance spectra of one cell were recorded at several temperatures. The low-frequency diffusion tail may come from a semi-infinite Warburg element or from a finite-length (transmissive) Warburg element. Decide which of the two the data support, estimate the circuit parameters at every temperature, and derive the apparent activation energy of the charge-transfer resistance. Deliver the analysis as a reusable program: it is also run on three unseen datasets. All datasets, visible or not, are synthetic.

## Input

`/root/data/spectra.csv` has the header `temperature_k,frequency_hz,zre_ohm,zim_ohm`, one row per (temperature, frequency), in any order. The complex impedance of a row is $ Z = Z_\text{re} + jZ_\text{im} $ in $ \Omega $, where $ Z_\text{re} $ is `zre_ohm`, $ Z_\text{im} $ is `zim_ohm` and $ j^2 = -1 $ (capacitive $ Z_\text{im} < 0 $, inductive $ Z_\text{im} > 0 $). `/root/data/metadata.json` holds `dataset_id` (string), `data_origin` (string), the measurement fixture `fixture.series_resistance_ohm` ($ R_\text{fix} $, in $ \Omega $) and `fixture.series_inductance_h` ($ L_\text{fix} $, in H), and `prediction_frequencies_hz` (list of frequencies in Hz, ascending).

## Model

With $ \omega = 2\pi f $, the model for the measured impedance $ Z_\text{meas} $ at every temperature is $ Z_\text{fixture} + Z_\text{cell} $, where

$$
Z_\text{fixture} = R_\text{fix} + j\omega L_\text{fix}, \qquad Z_\text{cell} = R_s + Z_\text{ct} + Z_D, \qquad Z_\text{ct} = \left(\frac{1}{R_\text{ct}} + Q\,(j\omega)^{\alpha}\right)^{-1}, \qquad (j\omega)^{\alpha} = \omega^{\alpha} e^{j\pi\alpha/2},
$$

and the diffusion impedance is either

$$
Z_D = \sigma\,\frac{1 - j}{\sqrt{\omega}} \quad \text{(semi-infinite)} \qquad \text{or} \qquad Z_D = R_D\,\frac{\tanh\sqrt{j\omega\tau_D}}{\sqrt{j\omega\tau_D}}, \quad \sqrt{j\omega\tau_D} = \sqrt{\omega\tau_D}\,e^{j\pi/4} \quad \text{(finite-length)}.
$$

Units: $ R_s $, $ R_\text{ct} $, $ R_D $ in $ \Omega $; $ Q $ in $ \mathrm{S\,s^{\alpha}} $; $ \alpha $ dimensionless; $ \sigma $ in $ \Omega\,\mathrm{s^{-1/2}} $; $ \tau_D $ in s. For the finite-length model $ \sigma \equiv R_D/\sqrt{2\tau_D} $; report $ \sigma $ as `warburg_sigma` for both models. Each temperature has its own independent parameter set (semi-infinite: $ R_s, R_\text{ct}, Q, \alpha, \sigma $; finite-length: $ R_s, R_\text{ct}, Q, \alpha, \sigma, \tau_D $), restricted to $ R_s \in [10^{-3}, 10^{3}] $, $ R_\text{ct} \in [10^{-2}, 10^{5}] $, $ Q \in [10^{-9}, 1] $, $ \alpha \in [0.5, 1] $, $ \sigma \in [10^{-4}, 10^{4}] $ and $ \tau_D \in [10^{-3}, 10^{6}] $ in the units above.

Noise on the real and imaginary parts is independent, zero-mean Gaussian with a standard deviation proportional to $ \lvert Z_\text{meas}\rvert $ (the same relative level for all rows of a dataset). The estimator of each model is the global minimum, within the ranges above, of

$$
\mathrm{RSS} = \sum_\text{all rows} \frac{\lvert Z_\text{meas} - Z_\text{fixture} - Z_\text{cell}\rvert^{2}}{\lvert Z_\text{meas}\rvert^{2}},
$$

where $ Z_\text{meas} $ is the measured row (not fixture-corrected).

### Model comparison

For each model, pooled over all temperatures: $ n = 2N_\text{rows} $, where $ N_\text{rows} $ is the number of rows; $ k = 5N_T + 1 $ (semi-infinite) or $ k = 6N_T + 1 $ (finite-length), where $ N_T $ is the number of temperatures; and

$$
\mathrm{AICc} = n \ln(\mathrm{RSS}/n) + 2k + \frac{2k(k+1)}{n - k - 1}.
$$

With $ \Delta = \mathrm{AICc}_\text{semi-infinite} - \mathrm{AICc}_\text{finite-length} $, the finite-length model is selected only if $ \Delta > 10 $; otherwise the semi-infinite model is selected. `evidence` is `favors_finite_length` if $ \Delta > 10 $, `favors_semi_infinite` if $ \Delta < -10 $, else `inconclusive`.

### Activation energy

For the selected model, $ \ln R_\text{ct} = \ln R_\text{ct}(298.15\ \mathrm{K}) + (E_a/R)\,(1/T - 1/298.15\ \mathrm{K}) $ with $ R = 8.314462618\ \mathrm{J\,mol^{-1}\,K^{-1}} $, fitted by ordinary least squares of $ \ln R_\text{ct} $ on $ 1/T $ over all temperatures (equal weights).

## Deliverables

1. `/root/results/analyze_eis.py`, run as `python /root/results/analyze_eis.py --input-dir INPUT_DIRECTORY --output OUTPUT_JSON`. It reads `spectra.csv` and `metadata.json` from `INPUT_DIRECTORY` (same layout and schema as `/root/data`) and writes `OUTPUT_JSON`; the parent directory of `OUTPUT_JSON` exists. Repeated runs on the same input must give the same output, so seed any random number generator.
2. `/root/results/analysis.json`, the output of that program for `/root/data`.

Both must be regular files, not symbolic links.

The JSON file is a single object (standard JSON, no NaN or Infinity) with the keys below. Write floats at full double precision, as Python's `json` module does by default; the grader recomputes values from them.

| key | content |
|---|---|
| `dataset_id` | string copied from the metadata |
| `model_comparison` | object: `n_obs` (int); `semi_infinite` and `finite_length`, each an object with `n_params` (int), `rss` (float, the minimised RSS), `aicc` (float) and `parameters` (that model's estimates, an array laid out like `temperatures`); `delta_aicc` (float); `evidence` (`favors_finite_length`, `favors_semi_infinite` or `inconclusive`); `selected_model` (`semi_infinite` or `finite_length`) |
| `temperatures` | the `parameters` array of the selected model: one object per temperature, ascending in temperature, with `temperature_k`, `r_s_ohm`, `r_ct_ohm`, `cpe_q`, `cpe_alpha`, `warburg_sigma`, `r_d_ohm`, `tau_d_s`. The last two are `null` for the semi-infinite model; for the finite-length model `r_d_ohm` is $ R_D = \sigma\sqrt{2\tau_D} $ |
| `arrhenius` | object: `activation_energy_kj_mol` ($ E_a $ in kJ/mol), `r_ct_298_15k_ohm` (regression value of $ R_\text{ct} $ at 298.15 K, in $ \Omega $) |
| `predictions` | object: `frequency_hz` (a copy of `prediction_frequencies_hz`), `cell_zre_ohm` and `cell_zim_ohm` (arrays indexed `[temperature][frequency]`, temperatures ascending, holding the real and imaginary parts of $ Z_\text{cell} $ of the selected model at the parameters in `temperatures`; fixture excluded) |

## Grading

The outcome is pass or fail. Five results are graded: `analysis.json`, the program re-run on `/root/data`, and the program run on three unseen datasets whose inputs are kept out of your container. They are different draws from the same synthetic family: 5 to 8 temperatures between 270 K and 345 K, upper frequency $ 3\cdot10^{4} $ to $ 10^{6} $ Hz, lower frequency $ 2\cdot10^{-3} $ to $ 10^{-1} $ Hz, 4 to 12 points per decade, relative noise 0.1 to 1 % per component, $ R_\text{fix} $ 0.05 to 0.5 $ \Omega $, $ L_\text{fix} $ 0.1 to 1.5 µH, and either diffusion model as the true one. Every check on every one of the five results must pass. The program is also run a second time on `/root/data`, and that output must reproduce the first run.

The grader recomputes the RSS of each model from that model's `parameters` and the input spectra, and $ Z_\text{cell} $ from `temperatures`. Below, $ f_\text{min} $ is the lowest measured frequency of the dataset, and a generating value is the parameter value the data were synthesised with.

| quantity | requirement |
|---|---|
| second run on `/root/data` | same output as the first run: identical keys, array lengths, strings and nulls, and every number equal to relative $ 10^{-9} $ |
| `rss` of each model | equals the recomputed RSS (relative $ 10^{-6} $) |
| recomputed RSS of each model | from 0.01 % below to 2 % above the global minimum of the objective |
| `temperatures` | equals the selected model's `parameters`, value by value (relative $ 10^{-9} $) |
| `cell_zre_ohm`, `cell_zim_ohm` | equal the recomputed $ Z_\text{cell} $ at every temperature and frequency: $ \lvert Z_\text{reported} - Z_\text{recomputed}\rvert / \lvert Z_\text{recomputed}\rvert \le 10^{-6} $ |
| `n_obs`, `n_params`, `aicc`, `delta_aicc`, `evidence`, `selected_model`, `activation_energy_kj_mol`, `r_ct_298_15k_ohm` | follow from the formulas and rules above applied to your reported `rss` and `r_ct_ohm` (relative $ 10^{-6} $) |
| `r_d_ohm` of every finite-length entry | equals $ \sigma\sqrt{2\tau_D} $ of the same entry (relative $ 10^{-5} $) |
| `selected_model` | equals the model that generated the data |
| `evidence` | equals the label implied by the globally minimal fits |
| `r_s_ohm`, `r_ct_ohm`, `warburg_sigma` in `temperatures` | within 5 %, 8 %, 5 % of the generating value at every temperature |
| `cpe_alpha` in `temperatures` | within 0.08 (absolute) of the generating value at every temperature |
| `activation_energy_kj_mol`, `r_ct_298_15k_ohm` | within 2.5 %, 3 % of the generating values |
| `cell_zre_ohm`, `cell_zim_ohm` at $ f \ge f_\text{min} $ | $ \lvert Z_\text{pred} - Z_\text{true}\rvert / \lvert Z_\text{true}\rvert \le 0.03 $, where $ Z_\text{true} $ is the noise-free generating $ Z_\text{cell} $ |
| `tau_d_s`, `r_d_ohm` in `temperatures` | within 15 %, 10 % of the generating value, at temperatures where the generating $ 2\pi f_\text{min}\tau_D \le 3 $ |
| `cell_zre_ohm`, `cell_zim_ohm` at $ f < f_\text{min} $ | $ \le 0.06 $ in the same measure, at the same temperatures (all temperatures for semi-infinite data) |

Every reported parameter, in both `parameters` arrays and in `temperatures`, must lie in its range above. `cpe_q` is range-checked but not compared with the generating value.

## Execution of the program

The grader runs the program in a clean container with Python 3.12, numpy 2.3.5 and scipy 1.16.3; do not use any other third-party package. Only `analyze_eis.py` and `analysis.json` are copied there, so the program must be one self-contained file of at most 2 MiB that reads nothing but its input directory, which is read-only. Each run is a separate process without network access, started as an unprivileged user with standard input from `/dev/null`, an empty temporary directory as working directory, `HOME` and `TMPDIR`, and a minimal environment in which `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS` and `MKL_NUM_THREADS` are 1. A run is killed after 120 s of wall-clock time and is also limited to 4 GiB of virtual address space, 256 processes, 256 open files and 64 MiB per written file. It must exit with status 0 and leave `OUTPUT_JSON` as a regular file of at most 8 MiB.

You have 18000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
